/* Apresentação do chat. Não chama IA, não envia relatos nem lê páginas. */
(()=>{
  const root=document.getElementById('chrome-at-green');
  if(!root || root.dataset.visualEnhancement==='ready')return;
  root.dataset.visualEnhancement='ready';
  const find=id=>root.querySelector('#'+id);
  const conversation=find('report-assist-conversa');
  const overlay=find('error-modal-overlay');
  const input=find('report-assist-input');
  const background=find('nocturne-bg');
  const picker=find('btn-pick-item');
  const image=()=>{const img=document.createElement('img');img.src='assets/tars/tars-icon.png';img.alt='';return img};
  if(!conversation || !overlay || !input)return;
  // O TS conserva o estado e o clique; este botão mostra só o ícone aprovado.
  const syncPicker=()=>{
    if(!picker || picker.querySelector('svg'))return;
    const label=picker.classList.contains('picking')?'Encerrar seleção na tela':'Selecionar na tela';
    picker.setAttribute('aria-label',label);
    picker.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z"/></svg>';
  };
  if(picker)new MutationObserver(syncPicker).observe(picker,{childList:true});
  // A rota e a origem local continuam disponíveis no título do contexto.
  const context=find('report-current-page');
  const syncContext=()=>{
    if(!context)return;
    const original=context.textContent;
    const title=original.match(/^(.*) · \/.* · leitura local$/)?.[1];
    if(!title)return;
    context.title=original;
    context.textContent='Compartilhando “'+title+'”';
  };
  if(context)new MutationObserver(syncContext).observe(context,{childList:true});
  const sync=()=>{
    const empty=!conversation.querySelector('.report-assist-turno');
    overlay.dataset.chatState=empty?'empty':'conversation';
    overlay.classList.toggle('typing',!!input.value);
    if(background?.hidden)background.hidden=false;
    const welcome=conversation.querySelector('.chat-welcome');
    if(welcome && !welcome.querySelector('.welcome-symbol')){
      const mark=document.createElement('span');
      mark.className='welcome-symbol';mark.setAttribute('aria-hidden','true');
      mark.appendChild(image());
      const copy=document.createElement('span');
      copy.textContent=root.dataset.greeting || 'Vamos lá. Como posso ajudar?';
      welcome.replaceChildren(mark,copy);
    }
    conversation.querySelectorAll('.report-assist-turno.ia').forEach(turn=>{
      if(turn.querySelector('.answer-mark'))return;
      const mark=document.createElement('span');
      mark.className='answer-mark';mark.setAttribute('aria-hidden','true');
      mark.appendChild(image());
      turn.prepend(mark);
    });
  };
  new MutationObserver(sync).observe(conversation,{childList:true,subtree:true});
  if(background)new MutationObserver(()=>{if(background.hidden)background.hidden=false}).observe(background,{attributes:true,attributeFilter:['hidden']});
  let openTimer;
  let wasOpen=false;
  const syncOpen=()=>{
    const open=overlay.style.display!=='none' && !overlay.hidden;
    if(open && !wasOpen){
      clearTimeout(openTimer);overlay.classList.remove('chat-opening');
      void overlay.offsetWidth;overlay.classList.add('chat-opening');
      openTimer=setTimeout(()=>overlay.classList.remove('chat-opening'),1200);
    }
    wasOpen=open;
    overlay.classList.toggle('motion-paused',!open||document.hidden);
  };
  new MutationObserver(syncOpen).observe(overlay,{attributes:true,attributeFilter:['style','hidden']});
  document.addEventListener('visibilitychange',syncOpen);
  input.addEventListener('input',()=>{
    overlay.classList.toggle('typing',!!input.value);
  });
  const more=find('chat-more'),menu=find('chat-more-menu'),plus=find('chat-plus');
  const close=()=>{
    if(menu)menu.hidden=true;
    if(more)more.setAttribute('aria-expanded','false');
    if(plus)plus.open=false;
  };
  more?.addEventListener('click',()=>{
    if(!menu)return;
    menu.hidden=!menu.hidden;
    more.setAttribute('aria-expanded',String(!menu.hidden));
    if(plus)plus.open=false;
  });
  find('chat-menu-close')?.addEventListener('click',close);
  root.addEventListener('keydown',event=>{if(event.key==='Escape')close()});
  sync();
  syncPicker();
  syncContext();
  syncOpen();
})();
