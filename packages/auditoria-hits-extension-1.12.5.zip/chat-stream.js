/* Escrita progressiva de texto ou de um DOM já sanitizado. Sem rede. */
(()=>{
  function start(target,content,options={}){
    const rate=Math.max(40,Math.min(1200,options.rate||260));
    const log=target.closest('[role="log"]');
    const fragment=document.createDocumentFragment();
    if(typeof content==='string')fragment.appendChild(document.createTextNode(content));
    else if(content instanceof Node)fragment.appendChild(content.cloneNode(true));
    else throw new TypeError('Use texto ou um nó DOM sanitizado.');
    const pieces=[];
    const walker=document.createTreeWalker(fragment,NodeFilter.SHOW_TEXT);
    while(walker.nextNode()){
      const node=walker.currentNode;
      if(node.textContent.length)pieces.push({node,text:node.textContent});
    }
    fragment.querySelectorAll('*').forEach(element=>{
      if(element.textContent.trim()){
        element.hidden=true;
        element.setAttribute('data-typewriter-pending','');
      }
    });
    pieces.forEach(piece=>piece.node.textContent='');
    target.replaceChildren(fragment);
    log?.setAttribute('aria-busy','true');
    let index=0,offset=0,credit=0,lastTime=null,frame=0,ended=false,resolve;
    const finished=new Promise(done=>resolve=done);
    function expose(node){
      let element=node.parentElement;
      while(element && element!==target){
        if(element.hasAttribute('data-typewriter-pending')){
          element.hidden=false;
          element.removeAttribute('data-typewriter-pending');
        }
        element=element.parentElement;
      }
    }
    function complete(cancelled){
      if(ended)return;
      ended=true;cancelAnimationFrame(frame);
      options.signal?.removeEventListener('abort',stop);
      if(cancelled)target.querySelectorAll('[data-typewriter-pending]').forEach(el=>el.remove());
      log?.setAttribute('aria-busy','false');
      resolve({cancelled,text:target.textContent});
    }
    function stop(){complete(true)}
    function tick(time){
      if(ended)return;
      const elapsed=lastTime===null?16:Math.min(64,time-lastTime);
      lastTime=time;credit+=elapsed*rate/1000;
      let budget=Math.floor(credit);credit-=budget;
      while(budget>0 && index<pieces.length){
        const piece=pieces[index];
        const take=Math.min(budget,piece.text.length-offset);
        expose(piece.node);
        piece.node.appendData(piece.text.slice(offset,offset+take));
        offset+=take;budget-=take;
        if(offset===piece.text.length){index++;offset=0}
      }
      options.onProgress?.(target.textContent);
      if(index===pieces.length)complete(false);
      else frame=requestAnimationFrame(tick);
    }
    if(options.signal?.aborted)stop();
    else{options.signal?.addEventListener('abort',stop,{once:true});frame=requestAnimationFrame(tick)}
    return {finished,stop};
  }
  globalThis.ChatATStream={start};
})();
